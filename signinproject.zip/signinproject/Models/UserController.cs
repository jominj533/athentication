﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace signinproject.Models
{
    public class UserController
    {
        public int Number { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}